# SystemSentinel User Manual

SystemSentinel is a DabelTech desktop diagnostic tool for Windows and macOS. It checks hardware and software health, identifies confirmed faults, predicts likely future problems, and suggests repair actions.

## 1. Trial and Premium Access

Each desktop installation includes a seven-day full-feature trial. The trial starts when SystemSentinel is first opened.

During the trial, the app can:

- Scan hardware and software health.
- Display the computer name, model, generation, CPU, RAM, storage, screen resolution, and operating system.
- Report confirmed faults and likely future faults.
- Provide fault-specific repair recommendations.
- Export and print diagnostic reports.

When seven days have elapsed, the diagnostic dashboard is locked. The app displays the premium upgrade contact details:

- Phone: +234 806 216 8465
- Email: dabelinfotech@gmail.com

The trial clock is stored locally and records the last observed time to reduce clock-rollback abuse. The trial does not replace a full licensing system; premium activation and payment are handled by DabelTech.

## 2. Starting a Scan

1. Open SystemSentinel.
2. Confirm the detected computer model in the device summary.
3. Select **Scan now**.
4. Wait for the scan stages to complete:
   - System data
   - Power check
   - Disk health
   - Software logs
   - Fault review
5. Review the overall score and individual component cards.

The app refreshes its diagnostic data automatically during normal use.

## 3. Understanding the Report

### Overall system status

The score summarizes the current health of the monitored components. A warning or critical status means the related evidence and recommended action should be reviewed.

### Hardware health

SystemSentinel evaluates:

- CPU load and temperature indicators
- Memory pressure
- Storage capacity and estimated drive health
- Cooling and thermal load
- GPU temperature indicators
- Power and battery condition
- Network errors

### Software health

SystemSentinel evaluates:

- Operating system updates
- Drivers and peripherals
- Startup programs
- Security software status
- Application crashes and hangs
- Recent system or diagnostic logs
- File-system warning indicators

### Confirmed faults

Confirmed faults are current findings that exceed the diagnostic warning threshold. They are evidence-based indicators, not a substitute for a technician's physical inspection.

### Future-fault forecast

Forecast percentages are risk estimates based on the available operating-system signals and current health trends. Back up important data before acting on storage, battery, thermal, or power warnings.

## 4. Repair Recommendations

Recommendations are generated for the specific fault detected. Examples include:

- Reduce sustained CPU load and inspect cooling.
- Close memory-heavy applications or consider a RAM upgrade.
- Back up data and run SMART or disk verification for storage warnings.
- Clean vents and confirm fan operation for thermal problems.
- Update drivers for peripheral or adapter issues.
- Install operating-system and security updates.
- Disable unnecessary startup programs.
- Review event logs and crash reports for recurring software faults.
- Run file-system repair after backing up important data.

After completing a repair, restart the computer and run another scan to confirm whether the fault has cleared.

## 5. System Details

The Current system details section may display:

- Computer name
- Computer model
- Hardware generation
- Screen resolution
- CPU model
- Total and available RAM
- Drive capacity and usage
- Battery level
- Drive model
- Uptime
- Operating system version
- Startup application count

Some fields may show **Unavailable** when the operating system does not expose the information or when the app is running without native desktop access.

## 6. Reports and Support

Use **Export report** to save a text report containing the detected model, platform, health scores, confirmed faults, software checks, repair summary, diagnostic log, and recommended actions.

Use **Print report** to create a paper or PDF copy for a technician.

For premium access after the trial:

- Phone: +234 806 216 8465
- Email: dabelinfotech@gmail.com

## 7. Safety Notes

SystemSentinel reports and recommends; it does not automatically delete files, change drivers, repair the file system, modify security settings, or replace hardware. Back up important files before disk or file-system repairs, and consult a qualified technician for critical power, thermal, storage, or electrical faults.

## 8. Marketplace and Source

- Product page and downloads: https://zinox-audio.vercel.app/system-sentinel.html
- Online manual: https://zinox-audio.vercel.app/system-sentinel-manual.html
- Source package: https://zinox-audio.vercel.app/downloads/SystemSentinel-source.zip
- Publisher: DabelTech
