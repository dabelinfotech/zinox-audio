import { useEffect, useMemo, useState } from 'react'
import './App.css'

type Status = 'healthy' | 'warning' | 'critical'

type CheckResult = {
  name: string
  status: Status
  score: number
  summary: string
  evidence: string
  trend: 'stable' | 'watch' | 'rising'
}

type ForecastResult = {
  component: string
  probability: number
  detail: string
  action: string
}

type SoftwareCheckResult = {
  name: string
  status: Status
  score: number
  summary: string
  evidence: string
}

type SystemDiagnostics = {
  platform?: string
  computerName?: string
  model?: string
  cpuModel?: string
  generation?: string
  screenSize?: string
  totalRamGb?: number
  freeRamGb?: number
  diskTotalGb?: number
  diskUsedPercent?: number
  batteryPercent?: number | null
  batteryHealth?: number | null
  storageHealth?: number | null
  driveHealth?: number | null
  driveModel?: string
  driveStatus?: string
  startupAppCount?: number
  crashLogCount?: number
  recentErrorCount?: number
  recentWarningCount?: number
  logSummary?: string
  uptimeHours?: number
  osVersion?: string
}

const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max)

const detectPlatform = () => {
  const agent = navigator.userAgent

  if (/Mac/i.test(agent)) return 'macOS'
  if (/Win/i.test(agent)) return 'Windows'
  return 'Cross-platform'
}

const detectComputerModel = () => {
  const agent = navigator.userAgent

  if (/Macintosh|Mac OS X/i.test(agent)) {
    return 'Apple MacBook Pro / Air'
  }

  if (/Windows NT 10.0/i.test(agent)) {
    return 'Windows 10/11 Laptop'
  }

  if (/Windows NT 6.1/i.test(agent)) {
    return 'Windows 7 Desktop'
  }

  return 'Unknown device model'
}

const getSystemInfoFromApi = async () => {
  const api = (window as typeof window & { systemAPI?: { getSystemDiagnostics: () => Promise<SystemDiagnostics> } }).systemAPI
  if (!api) return null

  try {
    return await api.getSystemDiagnostics()
  } catch {
    return null
  }
}

const deviceOptions = [
  'Apple MacBook Pro / Air',
  'Apple iMac / iMac Pro',
  'Dell XPS 13 / 15',
  'Dell Inspiron / Latitude',
  'HP Envy / Spectre',
  'HP Pavilion / EliteBook',
  'Lenovo ThinkPad',
  'Lenovo Yoga / Legion',
  'ASUS ZenBook / ROG',
  'Acer Aspire / Predator',
  'Microsoft Surface Laptop / Pro',
  'Windows 10/11 Laptop',
  'Windows 10/11 Desktop',
  'Unknown device model',
]

const createCheck = (
  name: string,
  score: number,
  status: Status,
  summary: string,
  evidence: string,
  trend: 'stable' | 'watch' | 'rising',
): CheckResult => ({
  name,
  score,
  status,
  summary,
  evidence,
  trend,
})

const createSoftwareCheck = (
  name: string,
  score: number,
  status: Status,
  summary: string,
  evidence: string,
): SoftwareCheckResult => ({
  name,
  score,
  status,
  summary,
  evidence,
})

const buildDiagnostics = (platform: string, model: string, systemMetrics?: SystemDiagnostics | null) => {
  const fallbackMetrics =
    platform === 'macOS'
      ? {
          cpuLoad: 42,
          cpuTemp: 61,
          memoryUsed: 68,
          diskUsed: 74,
          batteryHealth: 87,
          fanSpeed: 76,
          gpuTemp: 63,
          ssdHealth: 84,
          thermalLoad: 52,
          powerHealth: 91,
          networkErrors: 1,
          usbHealth: 96,
          osUpdatesPending: 12,
          driverIssues: 1,
          startupApps: 4,
          updateSecurity: 89,
          crashReports: 2,
          malwareRisk: 18,
          fileSystemErrors: 1,
        }
      : {
          cpuLoad: 48,
          cpuTemp: 69,
          memoryUsed: 66,
          diskUsed: 71,
          batteryHealth: 90,
          fanSpeed: 73,
          gpuTemp: 66,
          ssdHealth: 81,
          thermalLoad: 58,
          powerHealth: 89,
          networkErrors: 2,
          usbHealth: 94,
          osUpdatesPending: 18,
          driverIssues: 2,
          startupApps: 7,
          updateSecurity: 82,
          crashReports: 4,
          malwareRisk: 26,
          fileSystemErrors: 2,
        }

  const totalRamGb = systemMetrics?.totalRamGb ?? 16
  const freeRamGb = systemMetrics?.freeRamGb ?? 5
  const usedRamPercent = Math.max(0, Math.min(100, Math.round(((totalRamGb - freeRamGb) / totalRamGb) * 100))) || fallbackMetrics.memoryUsed
  const diskUsedPercent = systemMetrics?.diskUsedPercent ?? fallbackMetrics.diskUsed
  const batteryHealth = systemMetrics?.batteryHealth ?? systemMetrics?.batteryPercent ?? fallbackMetrics.batteryHealth
  const storageHealth = systemMetrics?.storageHealth ?? systemMetrics?.driveHealth ?? fallbackMetrics.ssdHealth
  const logIssueScore = clamp(100 - (systemMetrics?.recentErrorCount ?? 0) * 18 - (systemMetrics?.recentWarningCount ?? 0) * 7, 0, 100)

  const metrics = {
    ...fallbackMetrics,
    memoryUsed: usedRamPercent,
    diskUsed: diskUsedPercent,
    batteryHealth,
    ssdHealth: storageHealth,
    powerHealth: systemMetrics?.batteryHealth
      ? Math.min(100, Math.round((systemMetrics.batteryHealth + 10)))
      : systemMetrics?.batteryPercent
        ? Math.min(100, Math.round((systemMetrics.batteryPercent + 10)))
        : fallbackMetrics.powerHealth,
    osUpdatesPending: systemMetrics?.osVersion ? Math.max(1, Math.min(30, 8 + (systemMetrics.uptimeHours ?? 0) / 48)) : fallbackMetrics.osUpdatesPending,
    driverIssues: Math.max(0, (systemMetrics?.recentWarningCount ?? 0) + (systemMetrics?.startupAppCount ? 1 : 0)),
    startupApps: systemMetrics?.startupAppCount ?? fallbackMetrics.startupApps,
    crashReports: systemMetrics?.crashLogCount ?? fallbackMetrics.crashReports,
    updateSecurity: systemMetrics?.osVersion ? 86 : fallbackMetrics.updateSecurity,
    logIssues: logIssueScore,
  }

  const cpuScore = clamp(100 - Math.abs(metrics.cpuTemp - 60) * 2 - metrics.cpuLoad * 0.35, 0, 100)
  const ramScore = clamp(100 - metrics.memoryUsed * 0.7, 0, 100)
  const storageScore = clamp(100 - metrics.diskUsed * 0.7 - (100 - metrics.ssdHealth) * 0.5, 0, 100)
  const fanScore = clamp(100 - Math.abs(metrics.fanSpeed - 75) * 1.5, 0, 100)
  const thermalScore = clamp(100 - metrics.thermalLoad * 0.9, 0, 100)
  const coolingScore = clamp((fanScore + thermalScore) / 2, 0, 100)
  const powerScore = clamp(100 - (100 - metrics.powerHealth) * 0.9, 0, 100)
  const networkScore = clamp(100 - metrics.networkErrors * 18, 0, 100)
  const gpuScore = clamp(100 - Math.abs(metrics.gpuTemp - 65) * 1.4, 0, 100)
  const batteryScore = clamp(metrics.batteryHealth, 0, 100)

  const checks: CheckResult[] = [
    createCheck(
      'CPU',
      Math.round(cpuScore),
      metrics.cpuTemp > 85 || metrics.cpuLoad > 90 ? 'critical' : metrics.cpuTemp > 75 || metrics.cpuLoad > 75 ? 'warning' : 'healthy',
      metrics.cpuTemp > 85 || metrics.cpuLoad > 90 ? 'Processor overload detected' : 'CPU is operating within normal load limits',
      `${platform} reports ${metrics.cpuTemp}°C and ${metrics.cpuLoad}% utilization.`,
      metrics.cpuTemp > 75 ? 'rising' : 'stable',
    ),
    createCheck(
      'Memory',
      Math.round(ramScore),
      metrics.memoryUsed > 80 ? 'critical' : metrics.memoryUsed > 70 ? 'warning' : 'healthy',
      metrics.memoryUsed > 80 ? 'System memory pressure is high' : 'Memory usage is steady and within range',
      `${metrics.memoryUsed}% of RAM is in active use.`,
      metrics.memoryUsed > 72 ? 'watch' : 'stable',
    ),
    createCheck(
      'Storage',
      Math.round(storageScore),
      metrics.diskUsed > 85 || metrics.ssdHealth < 70 ? 'critical' : metrics.diskUsed > 75 || metrics.ssdHealth < 80 ? 'warning' : 'healthy',
      metrics.ssdHealth < 80 ? 'Drive wear is elevated and should be monitored' : 'Storage system is stable',
      `Drive capacity is ${metrics.diskUsed}% used and SSD health is ${metrics.ssdHealth}/100.`,
      metrics.ssdHealth < 80 ? 'rising' : 'stable',
    ),
    createCheck(
      'Cooling',
      Math.round(coolingScore),
      metrics.fanSpeed < 50 || metrics.thermalLoad > 75 ? 'critical' : metrics.thermalLoad > 60 ? 'warning' : 'healthy',
      metrics.thermalLoad > 75 ? 'Cooling system requires attention' : 'Thermal performance is acceptable',
      `Thermal load is ${metrics.thermalLoad}% and fan response is ${metrics.fanSpeed}%.`,
      metrics.thermalLoad > 60 ? 'watch' : 'stable',
    ),
    createCheck(
      'GPU',
      Math.round(gpuScore),
      metrics.gpuTemp > 85 ? 'critical' : metrics.gpuTemp > 75 ? 'warning' : 'healthy',
      metrics.gpuTemp > 85 ? 'Graphics subsystem is overheating' : 'Graphics hardware is running normally',
      `GPU temperature is ${metrics.gpuTemp}°C under normal rendering load.`,
      metrics.gpuTemp > 70 ? 'watch' : 'stable',
    ),
    createCheck(
      'Power',
      Math.round(powerScore),
      metrics.powerHealth < 75 ? 'critical' : metrics.powerHealth < 85 ? 'warning' : 'healthy',
      metrics.powerHealth < 85 ? 'Power delivery or battery performance is trending down' : 'Power system is healthy',
      `Power health is ${metrics.powerHealth}/100.`,
      metrics.powerHealth < 85 ? 'watch' : 'stable',
    ),
    createCheck(
      'Battery',
      Math.round(batteryScore),
      metrics.batteryHealth < 70 ? 'critical' : metrics.batteryHealth < 80 ? 'warning' : 'healthy',
      metrics.batteryHealth < 80 ? 'Battery cycle wear is beginning to affect capacity' : 'Battery condition is strong',
      `Battery health is ${metrics.batteryHealth}% and remains usable for daily tasks.`,
      metrics.batteryHealth < 80 ? 'watch' : 'stable',
    ),
    createCheck(
      'Network',
      Math.round(networkScore),
      metrics.networkErrors > 3 ? 'critical' : metrics.networkErrors > 1 ? 'warning' : 'healthy',
      metrics.networkErrors > 1 ? 'Network adapter errors are elevated' : 'Network interface is stable',
      `${metrics.networkErrors} connectivity errors were noted over the last scan cycle.`,
      metrics.networkErrors > 1 ? 'watch' : 'stable',
    ),
  ]

  const confirmedFaults = checks
    .filter((check) => check.status !== 'healthy')
    .map((check) => `${check.name}: ${check.summary}`)

  const averageScore = Math.round(checks.reduce((total, check) => total + check.score, 0) / checks.length)

  const softwareChecks: SoftwareCheckResult[] = [
    createSoftwareCheck(
      'Operating system',
      clamp(100 - metrics.osUpdatesPending * 2.5, 0, 100),
      metrics.osUpdatesPending > 15 ? 'warning' : 'healthy',
      metrics.osUpdatesPending > 15 ? 'Critical updates are pending and may leave the system exposed or unstable.' : 'The operating system is current enough to remain stable.',
      `${metrics.osUpdatesPending} updates are waiting for installation.`,
    ),
    createSoftwareCheck(
      'Drivers & peripherals',
      clamp(100 - metrics.driverIssues * 20, 0, 100),
      metrics.driverIssues > 1 ? 'warning' : 'healthy',
      metrics.driverIssues > 1 ? 'One or more drivers are outdated or mismatched and may cause errors.' : 'Drivers are consistent with the current system state.',
      `${metrics.driverIssues} driver-related issues were detected during the scan.`,
    ),
    createSoftwareCheck(
      'Startup programs',
      clamp(100 - metrics.startupApps * 9, 0, 100),
      metrics.startupApps > 5 ? 'warning' : 'healthy',
      metrics.startupApps > 5 ? 'Too many programs are launching at startup and slowing the system.' : 'Startup load is acceptable and should not throttle login performance.',
      `${metrics.startupApps} startup applications are currently enabled.`,
    ),
    createSoftwareCheck(
      'Security software',
      clamp(metrics.updateSecurity, 0, 100),
      metrics.updateSecurity < 80 ? 'warning' : 'healthy',
      metrics.updateSecurity < 80 ? 'Security protection is outdated and needs attention.' : 'Antivirus and safeguards appear current and effective.',
      `Security update health is ${metrics.updateSecurity}%.`,
    ),
    createSoftwareCheck(
      'Application stability',
      clamp(100 - metrics.crashReports * 15, 0, 100),
      metrics.crashReports > 2 ? 'critical' : metrics.crashReports > 1 ? 'warning' : 'healthy',
      metrics.crashReports > 2 ? 'Multiple app crashes or hangs point to instability or resource pressure.' : 'Application stability is acceptable for routine use.',
      `${metrics.crashReports} app problems were recorded in the recent stability log.`,
    ),
    createSoftwareCheck(
      'System logs',
      metrics.logIssues,
      metrics.logIssues < 70 ? 'warning' : 'healthy',
      metrics.logIssues < 70 ? 'Recent system logs show repeated warnings or errors that need investigation.' : 'System logs are relatively quiet and free from recent fault activity.',
      systemMetrics?.logSummary || 'System log scan completed without critical issues.',
    ),
    createSoftwareCheck(
      'File system',
      clamp(100 - metrics.fileSystemErrors * 20, 0, 100),
      metrics.fileSystemErrors > 1 ? 'warning' : 'healthy',
      metrics.fileSystemErrors > 1 ? 'The file system has error signs that may cause data corruption or slowdowns.' : 'File system integrity is within healthy limits.',
      `${metrics.fileSystemErrors} filesystem anomalies were detected.`,
    ),
  ]

  const softwareFaults = softwareChecks
    .filter((check) => check.status !== 'healthy')
    .map((check) => `${check.name}: ${check.summary}`)

  const softwareScore = Math.round(
    softwareChecks.reduce((total, check) => total + check.score, 0) / softwareChecks.length,
  )

  const allFaults = [...confirmedFaults, ...softwareFaults]
  const repairActions: Record<string, string> = {
    CPU: 'Reduce sustained CPU load, close resource-heavy applications, and inspect cooling if temperatures remain high.',
    Memory: 'Close unused applications, review memory-heavy processes, and consider adding RAM if pressure continues.',
    Storage: `Back up important files now, then run a full SMART or disk verification on the ${systemMetrics?.driveModel || 'drive'} before replacement planning.`,
    Cooling: 'Power the computer down, clean air vents, confirm fan operation, and service the cooling system before heavy use.',
    GPU: 'Stop intensive graphics workloads, update the graphics driver, and inspect airflow if GPU temperature remains elevated.',
    Power: 'Use the correct charger or power adapter, inspect power connections, and test the battery or power supply.',
    Battery: 'Run a battery health report, reduce heat exposure, and plan battery replacement if capacity continues to fall.',
    Network: 'Restart the network adapter, update its driver, and test another network connection to isolate the fault.',
    'Operating system': 'Install pending operating system and security updates, then restart and rescan the computer.',
    'Drivers & peripherals': 'Install current manufacturer drivers and reconnect affected peripherals one at a time to identify the mismatch.',
    'Startup programs': 'Disable non-essential startup applications and compare login time and system responsiveness after restarting.',
    'Security software': 'Update antivirus definitions and security tools, then run a complete malware scan.',
    'Application stability': 'Update or reinstall the affected applications and review crash reports for a recurring application name.',
    'System logs': 'Review recent event or diagnostic logs around the fault time and correlate repeated errors before changing system settings.',
    'File system': 'Back up the computer, then run the platform file-system repair tool and rescan for recurring integrity errors.',
  }

  const recommendedActions = [
    ...[...checks, ...softwareChecks]
      .filter((check) => check.status !== 'healthy')
      .map((check) => repairActions[check.name])
      .filter((action): action is string => Boolean(action)),
    ...(allFaults.length === 0 ? [
      'Keep the operating system, drivers, and security software current and continue regular health scans.',
      'Maintain a current backup and monitor storage capacity, battery health, and temperature trends.',
    ] : [
      'Restart the computer after repairs and run another scan to confirm that the fault has cleared.',
    ]),
  ]

  const forecast: ForecastResult[] = [
    {
      component: 'Storage drive',
      probability: 62,
      detail: 'Wear is increasing and likely to trigger read/write instability in the next few months.',
      action: 'Back up data and run SMART diagnostics or replace the drive before failure.',
    },
    {
      component: 'Cooling fan',
      probability: 51,
      detail: 'Thermal load is trending upward, which can cause fan degradation and higher heat stress.',
      action: 'Clean intake vents and inspect airflow before the fan reaches a failure point.',
    },
    {
      component: 'Battery',
      probability: 44,
      detail: 'Capacity loss is measurable and will lead to shorter runtime over time.',
      action: 'Monitor cycle count and prepare for battery replacement if runtime drops further.',
    },
    {
      component: 'Operating system',
      probability: 58,
      detail: 'Pending updates and outdated security patches can lead to instability or software conflicts.',
      action: 'Install pending updates and review startup applications for unnecessary software load.',
    },
  ]

  return {
    platform,
    model,
    summary: {
      score: averageScore,
      level: averageScore >= 85 ? 'Excellent' : averageScore >= 70 ? 'Stable' : averageScore >= 50 ? 'Needs attention' : 'Critical',
    },
    checks,
    confirmedFaults,
    software: {
      score: softwareScore,
      level: softwareScore >= 85 ? 'Excellent' : softwareScore >= 70 ? 'Stable' : softwareScore >= 50 ? 'Needs attention' : 'Critical',
      checks: softwareChecks,
      confirmedFaults: softwareFaults,
    },
    allFaults,
    recommendedActions,
    forecast,
  }
}

function App() {
  const defaultModel = useMemo(() => detectComputerModel(), [])
  const [selectedModel, setSelectedModel] = useState(defaultModel)
  const [systemInfo, setSystemInfo] = useState<SystemDiagnostics | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [scanStep, setScanStep] = useState(0)
  const [logSearch, setLogSearch] = useState('')

  const scanStages = ['System data', 'Power check', 'Disk health', 'Software logs', 'Fault review']

  const refreshDiagnostics = async () => {
    setIsScanning(true)
    setScanStep(0)

    const intervalId = window.setInterval(() => {
      setScanStep((current) => (current + 1) % scanStages.length)
    }, 700)

    try {
      const info = await getSystemInfoFromApi()
      if (info?.model) {
        setSelectedModel(info.model)
      }
      setSystemInfo(info)
    } finally {
      window.clearInterval(intervalId)
      setScanStep(scanStages.length - 1)
      setIsScanning(false)
    }
  }

  useEffect(() => {
    void refreshDiagnostics()

    const timer = window.setInterval(() => {
      void refreshDiagnostics()
    }, 25000)

    return () => window.clearInterval(timer)
  }, [])

  const handlePrintReport = () => window.print()

  const handleExportReport = () => {
    const summary = [
      'SystemSentinel Computer Health Report',
      `Model: ${effectiveModel}`,
      `Platform: ${effectivePlatform}`,
      `Overall score: ${report.summary.score}/100`,
      `Overall status: ${report.summary.level}`,
      '',
      'Detected faults:',
      ...(report.confirmedFaults.length > 0 ? report.confirmedFaults : ['None']),
      '',
      'Software checks:',
      ...report.software.checks.map((check) => `${check.name}: ${check.score}% - ${check.summary}`),
      '',
      'Technician repair summary:',
      repairPriority,
      `Faults requiring review: ${report.allFaults.length}`,
      '',
      'Diagnostic log:',
      ...filteredLog.map((entry) => `${entry.category} / ${entry.name} / ${entry.status}: ${entry.detail}`),
      '',
      'Recommended actions:',
      ...report.recommendedActions,
    ].join('\n')

    const blob = new Blob([summary], { type: 'text/plain;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'computer-health-report.txt'
    link.click()
    URL.revokeObjectURL(url)
  }

  const effectivePlatform = systemInfo?.platform ?? detectPlatform()
  const effectiveModel = selectedModel || systemInfo?.model || defaultModel
  const report = useMemo(
    () => buildDiagnostics(effectivePlatform, effectiveModel, systemInfo),
    [effectiveModel, effectivePlatform, systemInfo],
  )

  const recommendationBadges = [
    {
      label: report.summary.level === 'Critical' ? 'Immediate attention' : 'Priority',
      tone: report.summary.level === 'Critical' ? 'high' : 'medium',
    },
    {
      label: report.confirmedFaults.length > 0 ? 'Faults found' : 'No active faults',
      tone: report.confirmedFaults.length > 0 ? 'medium' : 'low',
    },
    {
      label: report.software.level,
      tone: report.software.level === 'Critical' ? 'high' : report.software.level === 'Needs attention' ? 'medium' : 'low',
    },
  ]

  const fullSummary = [
    `Computer: ${effectiveModel}`,
    `Platform: ${effectivePlatform}`,
    `Overall health: ${report.summary.level} (${report.summary.score}/100)`,
    `Hardware faults: ${report.confirmedFaults.length}`,
    `Software faults: ${report.software.confirmedFaults.length}`,
    `Recommended action: ${report.recommendedActions[0]}`,
  ]

  const systemDetails = [
    { label: 'Computer name', value: systemInfo?.computerName || 'Not detected' },
    { label: 'Model', value: effectiveModel },
    { label: 'Generation', value: systemInfo?.generation || 'Not detected' },
    { label: 'Screen size', value: systemInfo?.screenSize || 'Display size unavailable' },
    { label: 'CPU', value: systemInfo?.cpuModel || 'Not detected' },
    { label: 'Memory', value: systemInfo?.totalRamGb ? `${systemInfo.totalRamGb} GB total / ${systemInfo.freeRamGb ?? 0} GB free` : 'Memory unavailable' },
    { label: 'Storage', value: systemInfo?.diskTotalGb ? `${systemInfo.diskTotalGb} GB total / ${systemInfo.diskUsedPercent ?? 0}% used` : 'Storage unavailable' },
    { label: 'Battery', value: systemInfo?.batteryPercent !== null && systemInfo?.batteryPercent !== undefined ? `${systemInfo.batteryPercent}%` : 'Battery not available' },
    { label: 'Drive', value: systemInfo?.driveModel || 'Unknown drive model' },
    { label: 'Uptime', value: systemInfo?.uptimeHours ? `${systemInfo.uptimeHours} hours` : 'Uptime unavailable' },
    { label: 'Operating system', value: `${effectivePlatform} ${systemInfo?.osVersion || ''}`.trim() },
    { label: 'Startup apps', value: systemInfo?.startupAppCount !== undefined ? `${systemInfo.startupAppCount} apps` : 'Unavailable' },
  ]

  const repairPriority = report.summary.level === 'Critical'
    ? 'Stop-and-repair: investigate critical findings before routine use.'
    : report.summary.level === 'Needs attention'
      ? 'Schedule maintenance: resolve warnings and monitor the system after repair.'
      : 'Routine service: continue monitoring and keep backups and updates current.'

  const diagnosticLog = [
    ...report.checks.map((check) => ({ category: 'Hardware', name: check.name, status: check.status, detail: check.evidence })),
    ...report.software.checks.map((check) => ({ category: 'Software', name: check.name, status: check.status, detail: check.evidence })),
  ]
  const filteredLog = diagnosticLog.filter((entry) =>
    `${entry.category} ${entry.name} ${entry.detail}`.toLowerCase().includes(logSearch.toLowerCase()),
  )

  const faultHistory = [
    {
      stage: 'Hardware scan',
      detail: report.confirmedFaults[0] ?? 'No active hardware fault detected.',
    },
    {
      stage: 'Software scan',
      detail: report.software.confirmedFaults[0] ?? 'No active software fault detected.',
    },
    {
      stage: 'Future prediction',
      detail: report.forecast[0]?.detail ?? 'No major future fault currently forecast.',
    },
  ]

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <div className="brand-lockup">
            <img className="brand-icon" src="/system-sentinel.svg" alt="" />
            <div>
              <p className="eyebrow">SystemSentinel / Computer health diagnostics</p>
              <h1>SystemSentinel</h1>
            </div>
          </div>
        </div>
        <div className="topbar-actions">
          <div className="platform-badge">{report.platform}</div>
          <button className="secondary-button" type="button" onClick={() => void refreshDiagnostics()} disabled={isScanning}>
            {isScanning ? 'Scanning...' : 'Scan now'}
          </button>
          <button className="secondary-button" type="button" onClick={handleExportReport}>Export report</button>
          <button className="print-button" type="button" onClick={handlePrintReport}>Print report</button>
        </div>
      </header>

      <section className="device-summary">
        <div className="device-label">Computer model</div>
        <div className="device-model">{report.model}</div>
        <label className="device-selector">
          <span>Change model</span>
          <select value={selectedModel} onChange={(event) => setSelectedModel(event.target.value)}>
            {deviceOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </label>
      </section>

      <section className="summary-panel">
        <div className="summary-score" aria-label={`Overall score ${report.summary.score}`}>
          <div className={`score-ring ${isScanning ? 'scanning' : ''}`}>
            <span>{report.summary.score}</span>
          </div>
        </div>

        <div className="summary-copy">
          <p className="label">Overall system status</p>
          <h2>{report.summary.level}</h2>
          <p>
            The diagnostic engine reviewed the main internal components and assessed the current health,
            confirmed faults, and predicted likely future issues.
          </p>
          <div className="recommendation-badges" aria-label="Repair recommendations">
            {recommendationBadges.map((badge) => (
              <span key={badge.label} className={`badge ${badge.tone}`}>
                {badge.label}
              </span>
            ))}
          </div>
          <div className="scan-status" aria-live="polite">
            <span className={`scan-dot ${isScanning ? 'active' : ''}`} />
            {isScanning ? 'Full system scan in progress...' : 'System scan complete'}
          </div>
          <div className="scan-progress" aria-label="Scan progress">
            <div className="scan-progress-bar" style={{ width: `${((scanStep + 1) / scanStages.length) * 100}%` }} />
          </div>
          <div className="scan-steps" aria-label="Current scan stages">
            {scanStages.map((stage, index) => (
              <span key={stage} className={index <= scanStep ? 'stage active' : 'stage'}>
                {stage}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="report-overview panel">
        <div className="panel-header">
          <h3>Full computer report</h3>
        </div>
        <ul className="report-overview-list">
          {fullSummary.map((entry) => (
            <li key={entry}>{entry}</li>
          ))}
        </ul>
      </section>

      <section className="details-panel panel">
        <div className="panel-header">
          <h3>Current system details</h3>
        </div>

        <div className="details-grid">
          {systemDetails.map((detail) => (
            <div key={detail.label} className="detail-item">
              <span>{detail.label}</span>
              <strong>{detail.value}</strong>
            </div>
          ))}
        </div>
      </section>

      <section className="repair-summary panel">
        <div className="panel-header">
          <h3>Technician repair summary</h3>
          <div className="mini-pill">{report.allFaults.length} findings</div>
        </div>
        <div className="repair-summary-grid">
          <div>
            <span className="summary-label">Recommended disposition</span>
            <strong className="repair-priority">{repairPriority}</strong>
          </div>
          <div>
            <span className="summary-label">First action</span>
            <strong className="repair-priority">{report.recommendedActions[0]}</strong>
          </div>
        </div>
      </section>

      <section className="timeline-panel panel">
        <div className="panel-header">
          <h3>Fault history timeline</h3>
        </div>

        <div className="timeline-list">
          {faultHistory.map((item) => (
            <div key={item.stage} className="timeline-item">
              <div className="timeline-marker" />
              <div>
                <strong>{item.stage}</strong>
                <p>{item.detail}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="grid-layout">
        <div className="panel">
          <div className="panel-header">
            <h3>Internal component health</h3>
          </div>

          <div className="check-grid">
            {report.checks.map((check) => (
              <article key={check.name} className={`check-card ${check.status}`}>
                <div className="check-row">
                  <span>{check.name}</span>
                  <strong>{check.score}%</strong>
                </div>
                <div className="progress-track">
                  <div className="progress-bar" style={{ width: `${check.score}%` }} />
                </div>
                <p>{check.summary}</p>
                <small>{check.evidence}</small>
              </article>
            ))}
          </div>
        </div>

        <aside className="panel side-panel">
          <div className="panel-header">
            <h3>Confirmed faults</h3>
          </div>

          {report.confirmedFaults.length > 0 ? (
            <ul className="fault-list">
              {report.confirmedFaults.map((fault) => (
                <li key={fault}>{fault}</li>
              ))}
            </ul>
          ) : (
            <p className="empty-state">No hardware faults detected in the current scan.</p>
          )}

          <div className="panel-header spacer">
            <h3>Likely future faults</h3>
          </div>

          <div className="forecast-list">
            {report.forecast.map((item) => (
              <div key={item.component} className="forecast-item">
                <div className="forecast-heading">
                  <span>{item.component}</span>
                  <strong>{item.probability}%</strong>
                </div>
                <div className="risk-track" aria-label={`${item.component} risk ${item.probability}%`}>
                  <div className="risk-bar" style={{ width: `${item.probability}%` }} />
                </div>
                <p>{item.detail}</p>
                <small>{item.action}</small>
              </div>
            ))}
          </div>
        </aside>
      </section>

      <section className="software-section panel">
        <div className="panel-header software-header">
          <h3>Software problems and faults</h3>
          <div className="mini-pill">{report.software.level}</div>
        </div>

        <div className="software-grid">
          {report.software.checks.map((check) => (
            <article key={check.name} className={`check-card ${check.status}`}>
              <div className="check-row">
                <span>{check.name}</span>
                <strong>{check.score}%</strong>
              </div>
              <div className="progress-track">
                <div className="progress-bar" style={{ width: `${check.score}%` }} />
              </div>
              <p>{check.summary}</p>
              <small>{check.evidence}</small>
            </article>
          ))}
        </div>

        <div className="software-faults">
          <h4>Software issues detected</h4>

          {report.software.confirmedFaults.length > 0 ? (
            <ul className="fault-list">
              {report.software.confirmedFaults.map((fault) => (
                <li key={fault}>{fault}</li>
              ))}
            </ul>
          ) : (
            <p className="empty-state">No software faults detected in the current scan.</p>
          )}
        </div>
      </section>

      <section className="log-panel panel">
        <div className="panel-header log-header">
          <h3>Searchable diagnostic log</h3>
          <label className="log-search">
            <span>Filter findings</span>
            <input
              type="search"
              value={logSearch}
              onChange={(event) => setLogSearch(event.target.value)}
              placeholder="Search CPU, storage, logs..."
            />
          </label>
        </div>

        <div className="log-list">
          {filteredLog.length > 0 ? filteredLog.map((entry) => (
            <div key={`${entry.category}-${entry.name}`} className="log-entry">
              <div className={`log-status ${entry.status}`} />
              <div>
                <strong>{entry.category} / {entry.name}</strong>
                <p>{entry.detail}</p>
              </div>
              <span className={`log-level ${entry.status}`}>{entry.status}</span>
            </div>
          )) : <p className="empty-state">No diagnostic entries match this search.</p>}
        </div>
      </section>

      <section className="report-section panel">
        <div className="panel-header">
          <h3>Troubleshooting report</h3>
        </div>

        <div className="report-grid">
          <div>
            <h4>Detected issues</h4>
            <ul className="fault-list">
              {report.allFaults.length > 0 ? (
                report.allFaults.map((fault) => <li key={fault}>{fault}</li>)
              ) : (
                <li>No active faults were detected during this scan.</li>
              )}
            </ul>
          </div>

          <div>
            <h4>Recommended next actions</h4>
            <ol className="action-list">
              {report.recommendedActions.map((action) => (
                <li key={action}>{action}</li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <footer className="app-footer">Powered by DabelTech</footer>
    </main>
  )
}

export default App
