# SystemSentinel Conversation Record

## Product

SystemSentinel is a Windows and macOS computer health diagnostics application powered by DabelTech.

## Features Added

- Hardware health checks for CPU, memory, storage, cooling, GPU, power, battery, and network.
- Software checks for operating system updates, drivers, startup programs, security software, application stability, system logs, and file-system health.
- Confirmed fault reporting and likely future-fault predictions.
- Computer model, computer name, CPU, generation, screen resolution, RAM, storage, battery, uptime, and operating system details.
- Scan-stage progress indicator and fault-history timeline.
- Technician repair summary and searchable diagnostic log.
- Future-fault risk bars.
- Text report export and print support.
- SystemSentinel branding and custom shield/pulse/check icon.
- Powered by DabelTech footer.

## Desktop Packaging

- Electron desktop shell for Windows and macOS.
- Windows NSIS installer and portable package scripts.
- macOS DMG package script.
- Branded packaging icon generated from `public/system-sentinel.svg`.
- macOS DMG creation must run on a macOS host.

## Project Commands

```bash
npm run dev
npm run desktop
npm run build
npm run package:win
npm run package:mac
```

## Repository

The project was published to the private GitHub repository:

https://github.com/dabelinfotech/system-sentinel

Initial published commit: `a1d0584 Build SystemSentinel diagnostics app`

## Latest Updates

- Added a seven-day full diagnostic trial enforced by the packaged Electron app.
- Added local trial timestamp and clock-rollback protection.
- Added an expired-trial premium notice with phone `+234 806 216 8465` and email `dabelinfotech@gmail.com`.
- Added GitHub Actions automation to build and upload the macOS DMG on a macOS runner.
- Published Windows portable and macOS DMG assets to the `v0.1.0` GitHub release.
- Added `USER_MANUAL.md` covering installation, trial behavior, scanning, faults, repair recommendations, reports, and support.
- Included `USER_MANUAL.md` in Electron desktop package files.
- Added the manual link and seven-day trial download messaging to the ZinoxAudio Softwares marketplace page.
- Published the user manual as a hosted page on the marketplace (`system-sentinel-manual.html`) and removed the GitHub manual links shown to users.
- Renamed the Electron entry points to `electron.cjs` and `preload.cjs` to fix the packaged-app `require is not defined in ES module scope` crash.
- Rebuilt the Windows portable zip from the packaged output via `npm run package:portable`, fixing the crash that survived in that artifact, and replaced the `v0.1.0` release asset.
- Added the SystemSentinel project to the private `dabeltech/system-sentinel` mirror.

## Fix Record — Packaged App Crash (2026-09-17)

**Symptom.** The packaged Windows app failed on launch with a main-process error dialog:
`ReferenceError: require is not defined in ES module scope`, thrown at module load from
the bundled `electron.js`.

**Cause.** `package.json` declares `"type": "module"` because Vite requires it for the React
frontend. That flag makes Node parse every `.js` file in the package as an ES module,
including the CommonJS Electron main process. The bundled `package.json` ships the flag
alongside the entry point, so the crash appeared only in the packaged app and never in
`npm run desktop`.

**Fix.** Renamed the two CommonJS files so Node parses them as CommonJS regardless of the
package type:

- `electron.js` → `electron.cjs` and `preload.js` → `preload.cjs`, renamed with `git mv`.
- `package.json`: `main` → `electron.cjs`; `build.files` → `electron.cjs`, `preload.cjs`.
- `electron.cjs`: `webPreferences.preload` → `preload.cjs`.

The Vite and React side is unchanged; `dist/` stays ESM.

**Verification.** A minimal Electron app reproducing the exact condition — a package with
`"type": "module"` and a `.cjs` entry calling `require` — logged `MAIN_LOADED cjs ok`,
confirming `require` executes. `npm run package:win` rebuilt the NSIS and portable installers
cleanly, and both `electron.cjs` and `preload.cjs` are present inside `app.asar`.

## Manual Hosting Change

The product page previously linked the manual to the private `dabelinfotech/system-sentinel`
repository, which returns 404 for users. The manual is now a hosted page on the marketplace at
`website/system-sentinel-manual.html`, following the Zinox Lacquer manual pattern: sticky
sidebar contents, numbered scan steps, a repair-recommendation table, and tap-to-call and
mailto contacts. Both manual links on `system-sentinel.html`, and the link list in
`USER_MANUAL.md` section 8, now point at marketplace URLs instead of GitHub.

## Fix Record — Portable Zip Still Crashing (2026-09-17)

**Symptom.** After the `.cjs` rename shipped, the crash still reproduced from
`SystemSentinel-Windows-Portable.zip`. The dialog path showed a WinRAR temp folder
(`Temp\Rar$EXa...rartemp\`), meaning the archive was being run straight out of WinRAR.

**Cause.** The `.cjs` rename was verified against the electron-builder installers only. The
portable zip is a different artifact, produced by a hand-run of `electron-packager` against the
project directory, and it was never rebuilt. It still contained `"main": "electron.js"` and the
raw `electron.js`. Having no ignore list, that run also copied `node_modules`, `src` and
`release/` — both 113 MB installers included — into the download, unpacking to 794 MB.

**Fix.** Added `scripts/package-portable.mjs` and the `package:portable` script, which builds the
zip from `release/win-unpacked` instead. That output is asar-packed from `build.files`, so it
carries only `electron.cjs`, `preload.cjs`, `dist` and the manual. The archive keeps the
`SystemSentinel-win32-x64` layout so existing download links stay valid.

| | before | after |
| --- | --- | --- |
| Download | 324 MB | 155 MB |
| Unpacked | 794 MB | 387 MB |
| Entries | thousands | 74 |
| Entry point | `electron.js` | `electron.cjs` |

**Verification.** The built zip has zero `electron.js` or `preload.js` entries, no `node_modules`,
`src` or `release` leakage, and `"main": "electron.cjs"` inside `app.asar`. Extracted to a clean
folder and launched, it exits without the `ReferenceError` and writes nothing to stderr. The
window itself was not observed — the build shell has no display, so that check is manual.

**Release.** The `v0.1.0` asset was replaced in place with `gh release upload --clobber`, keeping
the filename so the manual and marketplace links serve the working build unchanged
(323,761,574 → 162,470,356 bytes).

**Lesson.** Two independent packaging paths existed for the same product. Verifying one proved
nothing about the other. Trace a reported error back to the specific artifact that produced it
before calling it fixed.

## Open Items

- `website/downloads/SystemSentinel-source.zip` predates the `.cjs` fix. Regenerate it, since
  the manual now sends users there.
- The macOS DMG on `v0.1.0` was built from pre-fix code and almost certainly carries the same
  crash, since `"type": "module"` with a `.js` main is platform-independent. Re-run the macOS
  workflow now that `master` has the fix, then replace that asset too.
- `npm run package:win` has not been re-run since `package.json` was restored (see below). The
  verified build predates the restore, and the file differs from it only in the three intended
  lines, but one rebuild would confirm.
- Both repositories are owned by `dabelinfotech` while the default local `gh` account is
  `dabeltech`. Pushing requires `gh auth switch --user dabelinfotech`.

**`package.json` restore.** During build inspection, `npx asar extract-file` wrote the packaged
`package.json` into the project root, overwriting `scripts`, the `build` config and
`devDependencies`. It was restored from `f86e8f7` with only the three intended edits
re-applied before the commit was pushed. Run `asar extract-file` from a scratch directory.

## Current Links

- Windows trial: https://github.com/dabelinfotech/system-sentinel/releases/download/v0.1.0/SystemSentinel-Windows-Portable.zip (rebuilt 2026-09-17)
- macOS trial: https://github.com/dabelinfotech/system-sentinel/releases/download/v0.1.0/SystemSentinel-macOS.dmg
- User manual: https://zinox-audio.vercel.app/system-sentinel-manual.html
- Marketplace: https://zinox-audio.vercel.app/system-sentinel.html
- DabelTech mirror: https://github.com/dabeltech/system-sentinel


Latest SystemSentinel commit: `302c68d Build the portable zip from the packaged output`
Latest marketplace commit: `2196274 Host the SystemSentinel user manual on the marketplace`
