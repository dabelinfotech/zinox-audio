# SystemSentinel Conversation Record

## Product

SystemSentinel is a Windows and macOS computer health diagnostics application powered by DabelTech.

## Features Added

- Hardware health checks for CPU, memory, storage, cooling, GPU, power, battery, and network.
- Software checks for operating system updates, drivers, startup programs, security software, application stability, system logs, and file-system health.
- Confirmed fault reporting and likely future-fault predictions.
- Computer model, computer name, CPU, generation, screen resolution, RAM, storage, battery, uptime, and operating system details.
- Scan-stage progress indicator and fault-history timeline.
- Technician repair summary and searchable diagnostic log.
- Future-fault risk bars.
- Text report export and print support.
- SystemSentinel branding and custom shield/pulse/check icon.
- Powered by DabelTech footer.

## Desktop Packaging

- Electron desktop shell for Windows and macOS.
- Windows NSIS installer and portable package scripts.
- macOS DMG package script.
- Branded packaging icon generated from `public/system-sentinel.svg`.
- macOS DMG creation must run on a macOS host.

## Project Commands

```bash
npm run dev
npm run desktop
npm run build
npm run package:win
npm run package:mac
```

## Repository

The project was published to the private GitHub repository:

https://github.com/dabelinfotech/system-sentinel

Initial published commit: `a1d0584 Build SystemSentinel diagnostics app`
