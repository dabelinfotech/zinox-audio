const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('systemAPI', {
  getSystemInfo: () => ipcRenderer.invoke('get-system-info'),
  getSystemDiagnostics: () => ipcRenderer.invoke('get-system-diagnostics'),
});
