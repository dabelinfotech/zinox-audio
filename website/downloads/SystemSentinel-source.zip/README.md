# SystemSentinel

SystemSentinel is a desktop computer health diagnostics tool for Windows and macOS. It reviews hardware and software signals, reports confirmed faults, highlights repair actions, and estimates likely future issues.

## Development

```bash
npm run dev
```

To launch the Electron desktop shell:

```bash
npm run desktop
```

To create a production build:

```bash
npm run build
```

## Desktop packages

On Windows, create an NSIS installer and portable executable:

```bash
npm run package:win
```

On macOS, create a DMG application package:

```bash
npm run package:mac
```

The packaging commands use the SystemSentinel shield icon. macOS DMG creation must be run on a Mac host; code signing and notarization can be added when Apple Developer credentials are available.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the Oxlint configuration

If you are developing a production application, we recommend enabling type-aware lint rules by installing `oxlint-tsgolint` and editing `.oxlintrc.json`:

```json
{
  "$schema": "./node_modules/oxlint/configuration_schema.json",
  "plugins": ["react", "typescript", "oxc"],
  "options": {
    "typeAware": true
  },
  "rules": {
    "react/rules-of-hooks": "error",
    "react/only-export-components": ["warn", { "allowConstantExport": true }]
  }
}
```

See the [Oxlint rules documentation](https://oxc.rs/docs/guide/usage/linter/rules) for the full list of rules and categories.
