import { mkdir } from 'node:fs/promises'
import sharp from 'sharp'

await mkdir('build/icons', { recursive: true })

await sharp('public/system-sentinel.svg')
  .resize(1024, 1024)
  .png()
  .toFile('build/icons/system-sentinel.png')

console.log('Generated build/icons/system-sentinel.png')
