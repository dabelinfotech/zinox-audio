// Builds the distributable Windows portable zip from the electron-builder
// unpacked output.
//
// The unpacked output is the only correct source for this artifact: it contains
// the asar-packed app built from build.files, so it ships electron.cjs and
// preload.cjs and nothing else. Packaging the project directory directly (as an
// earlier hand-run of electron-packager did) copies node_modules, src and
// release/ into the download and ships the CommonJS entry points under a
// "type": "module" package.json, which crashes the main process on launch.

import { execFileSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const source = path.join(root, 'release', 'win-unpacked');
const outputDir = path.join(root, 'release-portable');
const stageDir = path.join(outputDir, 'SystemSentinel-win32-x64');
const zipPath = path.join(outputDir, 'SystemSentinel-Windows-Portable.zip');

if (!existsSync(source)) {
  console.error(`Missing ${path.relative(root, source)}. Run "npm run package:win" first.`);
  process.exit(1);
}

rmSync(stageDir, { recursive: true, force: true });
rmSync(zipPath, { force: true });
mkdirSync(outputDir, { recursive: true });

console.log('Staging portable build...');
cpSync(source, stageDir, { recursive: true });

console.log('Compressing...');
execFileSync(
  'powershell',
  [
    '-NoProfile',
    '-NonInteractive',
    '-Command',
    `Compress-Archive -Path '${stageDir}' -DestinationPath '${zipPath}' -CompressionLevel Optimal -Force`,
  ],
  { stdio: 'inherit' },
);

rmSync(stageDir, { recursive: true, force: true });
console.log(`Wrote ${path.relative(root, zipPath)}`);
