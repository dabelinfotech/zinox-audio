const { app, BrowserWindow, ipcMain, screen } = require('electron');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

const isDev = !app.isPackaged;
const TRIAL_DAYS = 7;
const TRIAL_MS = TRIAL_DAYS * 24 * 60 * 60 * 1000;

function getTrialStatus() {
  const trialFile = path.join(app.getPath('userData'), 'trial-state.json');
  const now = Date.now();

  try {
    const stored = JSON.parse(require('fs').readFileSync(trialFile, 'utf8'));
    const firstRunAt = Number(stored.firstRunAt);
    const lastSeenAt = Number(stored.lastSeenAt);

    if (!Number.isFinite(firstRunAt) || !Number.isFinite(lastSeenAt)) {
      throw new Error('Invalid trial state');
    }

    const effectiveNow = Math.max(now, lastSeenAt);
    require('fs').writeFileSync(trialFile, JSON.stringify({ firstRunAt, lastSeenAt: effectiveNow }));
    const elapsedMs = Math.max(0, effectiveNow - firstRunAt);
    const remainingMs = Math.max(0, TRIAL_MS - elapsedMs);

    return {
      active: remainingMs > 0,
      expired: remainingMs <= 0,
      daysRemaining: Math.ceil(remainingMs / (24 * 60 * 60 * 1000)),
      firstRunAt,
      trialDays: TRIAL_DAYS,
    };
  } catch {
    require('fs').mkdirSync(path.dirname(trialFile), { recursive: true });
    require('fs').writeFileSync(trialFile, JSON.stringify({ firstRunAt: now, lastSeenAt: now }));
    return { active: true, expired: false, daysRemaining: TRIAL_DAYS, firstRunAt: now, trialDays: TRIAL_DAYS };
  }
}

function safeExec(command) {
  try {
    return execSync(command, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] }).trim();
  } catch {
    return '';
  }
}

function parseWindowsKeyValue(raw, keyName) {
  const line = raw
    .split(/\r?\n/)
    .find((entry) => entry.toLowerCase().includes(keyName.toLowerCase()));

  if (!line) return '';
  const match = line.split('=');
  return match.length > 1 ? match.slice(1).join('=').trim() : '';
}

function parseWindowsDisk(raw) {
  const lines = raw.split(/\r?\n/).filter(Boolean);
  const entries = lines.slice(1);

  if (!entries.length) return { totalGb: 0, freeGb: 0, usedPct: 0 };

  const first = entries[0].split(/\s+/);
  const deviceId = first[0];
  const size = Number(first[1] || 0);
  const free = Number(first[2] || 0);

  if (!size) return { totalGb: 0, freeGb: 0, usedPct: 0 };

  const totalGb = Math.round(size / 1024 / 1024 / 1024);
  const freeGb = Math.round(free / 1024 / 1024 / 1024);
  const usedPct = Math.max(0, Math.min(100, Math.round(((totalGb - freeGb) / totalGb) * 100)));

  return { deviceId, totalGb, freeGb, usedPct };
}

function getDisplaySize() {
  try {
    const display = screen.getPrimaryDisplay();
    return `${display.size.width} x ${display.size.height} px`;
  } catch {
    return 'Display size unavailable';
  }
}

function detectHardwareGeneration(model) {
  const intelMatch = model.match(/(?:i[3579]|Core Ultra)\s*(?:\(R\))?\s*-?\s*(\d{4,5})/i);
  if (intelMatch) {
    const series = intelMatch[1];
    return series.length === 5 ? `${series.slice(0, 2)}th generation` : `${series.slice(0, 1)}th generation`;
  }

  const appleMatch = model.match(/Apple\s+(M\d(?:\s+(?:Pro|Max|Ultra))?)/i);
  return appleMatch ? `${appleMatch[1]} generation` : 'Generation unavailable';
}

function getWindowsSystemInfo() {
  try {
    const model = parseWindowsKeyValue(
      safeExec('wmic computersystem get model /value'),
      'Model',
    ) || 'Windows PC';

    const ram = parseWindowsKeyValue(
      safeExec('wmic computersystem get totalphysicalmemory /value'),
      'TotalPhysicalMemory',
    );

    const totalRamGb = ram ? Math.round(Number(ram) / 1024 / 1024 / 1024) : Math.round(os.totalmem() / 1024 / 1024 / 1024);

    const cpuModel = parseWindowsKeyValue(
      safeExec('wmic cpu get name /value'),
      'Name',
    ) || 'Unknown CPU';
    const computerName = os.hostname();
    const generation = detectHardwareGeneration(cpuModel);

    const diskRaw = safeExec('wmic logicaldisk where drivetype=3 get Size,FreeSpace,DeviceID /value');
    const disk = parseWindowsDisk(diskRaw);

    const driveModel = safeExec('wmic diskdrive get model /value') || 'Unknown drive';
    const driveStatus = safeExec('wmic diskdrive get status /value') || 'Status unavailable';
    const driveHealth = disk.usedPct ? Math.max(0, Math.min(100, 100 - disk.usedPct * 0.7)) : 80;

    const batteryRaw = safeExec('powercfg /batteryreport');
    const batteryPercent = /Battery Capacity\s*:\s*(\d+)/i.test(batteryRaw)
      ? Number((batteryRaw.match(/Battery Capacity\s*:\s*(\d+)/i) || [])[1])
      : null;

    const batteryHealth = batteryPercent ? Math.max(0, Math.min(100, batteryPercent)) : null;
    const storageHealth = driveHealth;

    const startupRaw = safeExec('reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run"');
    const startupAppCount = startupRaw ? (startupRaw.match(/REG_[A-Z]+/g) || []).length : 0;

    const eventLogRaw = safeExec('wevtutil qe Application /q:"*[System[(Level=2 or Level=3)]]" /f:text /c:50');
    const recentErrorCount = eventLogRaw ? (eventLogRaw.match(/Event ID\s*:\s*(\d+)/gi) || []).length : 0;
    const recentWarningCount = eventLogRaw ? (eventLogRaw.match(/Level:\s*Warning/gi) || []).length : 0;

    const crashLogRaw = safeExec('dir "%USERPROFILE%\\AppData\\Local\\CrashDumps" /b 2>nul');
    const crashLogCount = crashLogRaw ? crashLogRaw.split(/\r?\n/).filter(Boolean).length : 0;

    const logSummary = recentErrorCount > 0 || recentWarningCount > 0
      ? `${recentErrorCount} critical and ${recentWarningCount} warning events detected in the last application log scan.`
      : 'No recent event log faults were detected.';

    return {
      platform: 'Windows',
      computerName,
      model,
      cpuModel,
      generation,
      screenSize: getDisplaySize(),
      totalRamGb,
      freeRamGb: Math.max(0, totalRamGb - Math.round((disk.usedPct / 100) * totalRamGb)),
      diskTotalGb: disk.totalGb || totalRamGb,
      diskUsedPercent: disk.usedPct || 50,
      batteryPercent,
      batteryHealth,
      storageHealth,
      startupAppCount,
      crashLogCount,
      recentErrorCount,
      recentWarningCount,
      driveHealth,
      driveModel,
      driveStatus,
      logSummary,
      uptimeHours: Math.round(os.uptime() / 3600),
      osVersion: safeExec('ver') || 'Windows',
    };
  } catch (error) {
    return {
      platform: 'Windows',
      computerName: os.hostname(),
      model: 'Windows PC',
      cpuModel: 'Unknown CPU',
      generation: 'Generation unavailable',
      screenSize: getDisplaySize(),
      totalRamGb: Math.round(os.totalmem() / 1024 / 1024 / 1024),
      freeRamGb: 0,
      diskTotalGb: 0,
      diskUsedPercent: 0,
      batteryPercent: null,
      batteryHealth: null,
      storageHealth: null,
      startupAppCount: 0,
      crashLogCount: 0,
      recentErrorCount: 0,
      recentWarningCount: 0,
      driveHealth: 80,
      driveModel: 'Unknown drive',
      driveStatus: 'Unknown',
      logSummary: 'Unable to read Windows event logs.',
      uptimeHours: Math.round(os.uptime() / 3600),
      osVersion: 'Windows',
    };
  }
}

function getMacSystemInfo() {
  try {
    const model = safeExec('sysctl -n hw.model') || 'Apple Computer';
    const cpuModel = safeExec('sysctl -n machdep.cpu.brand_string') || model;
    const computerName = os.hostname();
    const generation = detectHardwareGeneration(cpuModel);
    const totalRamGb = Math.round(os.totalmem() / 1024 / 1024 / 1024);
    const freeRam = safeExec('vm_stat | tail -n 5');
    const freePagesMatch = freeRam.match(/Pages free:\s+(\d+)/i);
    const freePages = freePagesMatch ? Number(freePagesMatch[1]) : 0;
    const inactivePagesMatch = freeRam.match(/Pages inactive:\s+(\d+)/i);
    const inactivePages = inactivePagesMatch ? Number(inactivePagesMatch[1]) : 0;
    const freeRamGb = Math.max(0, Math.round(((freePages + inactivePages) * 4096 / 1024 / 1024 / 1024) * 10) / 10);

    const diskRaw = safeExec('df -k /');
    const diskLine = diskRaw.split(/\r?\n/).find((line) => line.trim().startsWith('/dev/')) || '';
    const diskValues = diskLine.split(/\s+/);
    const totalDiskKb = Number(diskValues[1] || 0);
    const usedDiskKb = Number(diskValues[2] || 0);
    const totalDiskGb = totalDiskKb ? Math.round(totalDiskKb / 1024 / 1024) : 0;
    const diskUsedPercent = totalDiskKb ? Math.max(0, Math.min(100, Math.round((usedDiskKb / totalDiskKb) * 100))) : 0;

    const batteryRaw = safeExec('pmset -g batt');
    const batteryPercentMatch = batteryRaw.match(/(\d+)%/);
    const batteryPercent = batteryPercentMatch ? Number(batteryPercentMatch[1]) : null;
    const batteryHealth = batteryPercent ? Math.min(100, Math.max(0, batteryPercent)) : null;

    const driveModel = safeExec('diskutil info / 2>/dev/null | grep "Device / Media Name" | head -n 1') || 'Unknown drive';
    const driveStatus = safeExec('diskutil list 2>/dev/null | head -n 20') ? 'Storage visible' : 'Unavailable';
    const driveHealth = totalDiskKb ? Math.max(0, Math.min(100, 100 - diskUsedPercent * 0.7)) : 80;

    const storageHealth = totalDiskKb ? Math.max(0, Math.min(100, 100 - diskUsedPercent * 0.7)) : null;
    const startupRaw = safeExec('ls ~/Library/LaunchAgents /Library/LaunchAgents 2>/dev/null');
    const startupAppCount = startupRaw ? startupRaw.split(/\r?\n/).filter(Boolean).length : 0;
    const crashLogRaw = safeExec('ls ~/Library/Logs/DiagnosticReports 2>/dev/null');
    const crashLogCount = crashLogRaw ? crashLogRaw.split(/\r?\n/).filter(Boolean).length : 0;
    const recentErrorCount = crashLogCount;
    const recentWarningCount = Math.max(0, Math.round(crashLogCount / 2));
    const logSummary = recentErrorCount > 0 || recentWarningCount > 0
      ? `${recentErrorCount} diagnostic reports and ${recentWarningCount} warning-level entries were found in the recent system log.`
      : 'No recent macOS system log problems were detected.';

    return {
      platform: 'macOS',
      computerName,
      model,
      cpuModel,
      generation,
      screenSize: getDisplaySize(),
      totalRamGb,
      freeRamGb,
      diskTotalGb: totalDiskGb,
      diskUsedPercent,
      batteryPercent,
      batteryHealth,
      storageHealth,
      startupAppCount,
      crashLogCount,
      recentErrorCount,
      recentWarningCount,
      driveHealth,
      driveModel,
      driveStatus,
      logSummary,
      uptimeHours: Math.round(os.uptime() / 3600),
      osVersion: safeExec('sw_vers -productVersion') || 'macOS',
    };
  } catch (error) {
    return {
      platform: 'macOS',
      computerName: os.hostname(),
      model: 'Apple Computer',
      cpuModel: 'Unknown CPU',
      generation: 'Generation unavailable',
      screenSize: getDisplaySize(),
      totalRamGb: Math.round(os.totalmem() / 1024 / 1024 / 1024),
      freeRamGb: 0,
      diskTotalGb: 0,
      diskUsedPercent: 0,
      batteryPercent: null,
      batteryHealth: null,
      storageHealth: null,
      startupAppCount: 0,
      crashLogCount: 0,
      recentErrorCount: 0,
      recentWarningCount: 0,
      driveHealth: 80,
      driveModel: 'Unknown drive',
      driveStatus: 'Unknown',
      logSummary: 'Unable to read macOS logs.',
      uptimeHours: Math.round(os.uptime() / 3600),
      osVersion: 'macOS',
    };
  }
}

function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1400,
    height: 1000,
    minWidth: 1080,
    minHeight: 760,
    title: 'SystemSentinel',
    icon: path.join(__dirname, 'build', 'icons', 'system-sentinel.png'),
    backgroundColor: '#020817',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.cjs'),
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  }
}

ipcMain.handle('get-system-info', () => {
  if (process.platform === 'win32') {
    return getWindowsSystemInfo();
  }

  if (process.platform === 'darwin') {
    return getMacSystemInfo();
  }

  return {
    platform: process.platform,
    model: 'Unknown device',
    cpuModel: 'Unknown CPU',
    totalRamGb: Math.round(os.totalmem() / 1024 / 1024 / 1024),
    freeRamGb: 0,
    diskTotalGb: 0,
    diskUsedPercent: 0,
    batteryPercent: null,
    batteryHealth: null,
    storageHealth: null,
    startupAppCount: 0,
    crashLogCount: 0,
    recentErrorCount: 0,
    recentWarningCount: 0,
    uptimeHours: Math.round(os.uptime() / 3600),
    osVersion: 'Unknown OS',
  };
});

ipcMain.handle('get-trial-status', () => getTrialStatus());

ipcMain.handle('get-system-diagnostics', () => {
  if (process.platform === 'win32') {
    return getWindowsSystemInfo();
  }

  if (process.platform === 'darwin') {
    return getMacSystemInfo();
  }

  return {
    platform: process.platform,
    model: 'Unknown device',
    cpuModel: 'Unknown CPU',
    totalRamGb: Math.round(os.totalmem() / 1024 / 1024 / 1024),
    freeRamGb: 0,
    diskTotalGb: 0,
    diskUsedPercent: 0,
    batteryPercent: null,
    batteryHealth: null,
    storageHealth: null,
    startupAppCount: 0,
    crashLogCount: 0,
    recentErrorCount: 0,
    recentWarningCount: 0,
    uptimeHours: Math.round(os.uptime() / 3600),
    osVersion: 'Unknown OS',
  };
});

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
